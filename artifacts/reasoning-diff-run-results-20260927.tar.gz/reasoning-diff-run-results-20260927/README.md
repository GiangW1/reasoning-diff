# reasoning-diff run results

This archive contains the compact outputs from the official iGSM runs on GPU 3
and GPU 6. It is an audit bundle, not a claim that the scientific protocol was
successfully evaluated.

## Included

- Stage manifests and run specifications.
- Dataset manifest.
- Labels, calibration records, offline intervention records, repair records,
  analysis tables, and final reports where each file is below 1 MiB.
- Failure records from the attempted prospective Qwen3 intervention.
- `summary.json` with counts and known limitations.

## Excluded large artifacts

- Model weights and caches.
- `features.npz` hidden-state arrays.
- Full `traces.jsonl` generations.
- `probes.jsonl` parameter matrices.
- Full task and edit payloads.

The excluded artifacts remain under `/mnt/mydata` on the experiment host.

## Interpretation

All final stage commands wrote successful manifests with `failure_count=0`.
However, every collected Qwen3 trace reached the 768-token generation limit
without a parsed final answer. The label sets therefore contain no positive
task or behavior labels. Prospective intervention failed because the installed
Transformers input checker rejected the Qwen3 forward signature; the included
intervention output is offline hidden-state geometry only. All repair records
are `mask_unmatched`, and the reports remain `not_evaluated` with a null
scientific conclusion because the sham protocol and registered gates are
missing.

